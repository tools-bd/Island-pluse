package com.jubayer.islandplus

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.util.concurrent.CopyOnWriteArrayList

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    fun get(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun set(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
    fun clearPosition(c: Context) =
        sp(c).edit().remove("y").remove("x").remove("w").remove("h").apply()
}

object IslandHost {
    val controllers = CopyOnWriteArrayList<IslandController>()
    var accessibilityController: IslandController? = null
    private val main = Handler(Looper.getMainLooper())

    fun refresh() = main.post { controllers.forEach { it.refresh() } }
    fun notify(text: String) = main.post { controllers.forEach { it.notify(text) } }

    // Accessibility mode on thakle foreground notification lage na
    fun accessibilityEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(
            c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.contains(c.packageName + "/")
    }
}

class IslandController(private val ctx: Context, private val type: Int) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var tv: TextView? = null
    private var bg: GradientDrawable? = null
    private var expanded = false
    private var currentText = ""
    private val collapse = Runnable { expanded = false; refresh() }

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics
    ).toInt()

    private fun bgColor(): Int = Color.rgb(
        Prefs.get(ctx, "cr", 0), Prefs.get(ctx, "cg", 0), Prefs.get(ctx, "cb", 0)
    )

    private fun fgColor(): Int {
        val c = bgColor()
        val lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
        return if (lum > 0.6) Color.BLACK else Color.WHITE
    }

    @Suppress("DEPRECATION")
    private fun params(): WindowManager.LayoutParams {
        val w = Prefs.get(ctx, "w", 103)
        val h = Prefs.get(ctx, "h", 29)
        val screenW = ctx.resources.displayMetrics.widthPixels
        val width = if (expanded) minOf(dp(w + 140), (screenW * 0.92f).toInt()) else dp(w)
        val height = if (expanded) dp(h + 10) else dp(h)
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        return WindowManager.LayoutParams(width, height, type, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = dp(Prefs.get(ctx, "x", 0))
            y = dp(Prefs.get(ctx, "y", 8))
        }
    }

    fun show() {
        if (tv != null) return
        val d = GradientDrawable().apply {
            setColor(bgColor())
            cornerRadius = dp(60).toFloat()
        }
        val t = TextView(ctx).apply {
            setTextColor(fgColor())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(10), 0, dp(10), 0)
            background = d
        }
        try {
            wm.addView(t, params())
            tv = t
            bg = d
            IslandHost.controllers.add(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun hide() {
        handler.removeCallbacks(collapse)
        tv?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        tv = null
        bg = null
        IslandHost.controllers.remove(this)
    }

    fun refresh() {
        val t = tv ?: return
        bg?.setColor(bgColor())
        t.setTextColor(fgColor())
        t.text = if (expanded) currentText else ""
        try { wm.updateViewLayout(t, params()) } catch (e: Exception) { }
    }

    fun notify(text: String) {
        if (tv == null) return
        currentText = text
        expanded = true
        refresh()
        handler.removeCallbacks(collapse)
        handler.postDelayed(collapse, 4000)
    }
}
