package com.jubayer.islandplus

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

// Lock screen + notification shade er upore dekhay, ar kono foreground notification lage na
class IslandAccessibilityService : AccessibilityService() {

    private var controller: IslandController? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        val c = IslandController(this, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        controller = c
        IslandHost.accessibilityController = c
        // Notification dewa service dorkar nei, bondho kore dao
        stopService(Intent(this, IslandService::class.java))
        if (Prefs.get(this, "enabled", 1) == 1) c.show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        controller?.hide()
        IslandHost.accessibilityController = null
        super.onDestroy()
    }
}
